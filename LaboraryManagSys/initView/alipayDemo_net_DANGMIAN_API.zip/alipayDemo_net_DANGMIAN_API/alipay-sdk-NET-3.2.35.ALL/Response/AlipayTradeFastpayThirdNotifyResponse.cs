using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayTradeFastpayThirdNotifyResponse.
    /// </summary>
    public class AlipayTradeFastpayThirdNotifyResponse : AopResponse
    {
    }
}
