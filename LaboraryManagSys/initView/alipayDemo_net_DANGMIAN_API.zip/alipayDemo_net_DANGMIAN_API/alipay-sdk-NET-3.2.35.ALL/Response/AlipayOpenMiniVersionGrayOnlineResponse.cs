using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenMiniVersionGrayOnlineResponse.
    /// </summary>
    public class AlipayOpenMiniVersionGrayOnlineResponse : AopResponse
    {
    }
}
