using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenMiniVersionRollbackResponse.
    /// </summary>
    public class AlipayOpenMiniVersionRollbackResponse : AopResponse
    {
    }
}
