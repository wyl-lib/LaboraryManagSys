using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipaySecurityProdFingerprintDeviceVerifyResponse.
    /// </summary>
    public class AlipaySecurityProdFingerprintDeviceVerifyResponse : AopResponse
    {
    }
}
