using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayEcoCplifeResidentinfoUploadResponse.
    /// </summary>
    public class AlipayEcoCplifeResidentinfoUploadResponse : AopResponse
    {
    }
}
