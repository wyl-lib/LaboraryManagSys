using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenSmsgDataSetResponse.
    /// </summary>
    public class AlipayOpenSmsgDataSetResponse : AopResponse
    {
    }
}
