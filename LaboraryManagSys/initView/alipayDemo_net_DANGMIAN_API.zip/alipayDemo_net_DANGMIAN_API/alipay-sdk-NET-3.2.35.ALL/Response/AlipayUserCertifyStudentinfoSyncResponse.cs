using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayUserCertifyStudentinfoSyncResponse.
    /// </summary>
    public class AlipayUserCertifyStudentinfoSyncResponse : AopResponse
    {
    }
}
