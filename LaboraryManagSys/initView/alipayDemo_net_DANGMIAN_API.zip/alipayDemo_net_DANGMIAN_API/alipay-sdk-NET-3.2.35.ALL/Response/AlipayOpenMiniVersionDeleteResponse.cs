using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenMiniVersionDeleteResponse.
    /// </summary>
    public class AlipayOpenMiniVersionDeleteResponse : AopResponse
    {
    }
}
