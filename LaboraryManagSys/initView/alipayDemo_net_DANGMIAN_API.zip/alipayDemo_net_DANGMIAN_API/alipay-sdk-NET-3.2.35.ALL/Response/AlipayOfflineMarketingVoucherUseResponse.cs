using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOfflineMarketingVoucherUseResponse.
    /// </summary>
    public class AlipayOfflineMarketingVoucherUseResponse : AopResponse
    {
    }
}
