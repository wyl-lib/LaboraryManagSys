using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenAppSmgMsgSendResponse.
    /// </summary>
    public class AlipayOpenAppSmgMsgSendResponse : AopResponse
    {
    }
}
