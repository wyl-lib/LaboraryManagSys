using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayDaoweiSpModifyResponse.
    /// </summary>
    public class AlipayDaoweiSpModifyResponse : AopResponse
    {
    }
}
