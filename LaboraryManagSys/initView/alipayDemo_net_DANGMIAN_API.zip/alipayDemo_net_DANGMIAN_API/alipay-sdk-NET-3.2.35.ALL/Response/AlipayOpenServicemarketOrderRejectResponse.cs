using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenServicemarketOrderRejectResponse.
    /// </summary>
    public class AlipayOpenServicemarketOrderRejectResponse : AopResponse
    {
    }
}
