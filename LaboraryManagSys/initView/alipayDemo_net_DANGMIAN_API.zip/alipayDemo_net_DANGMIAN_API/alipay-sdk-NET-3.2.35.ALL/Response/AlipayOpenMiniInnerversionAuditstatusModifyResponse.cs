using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenMiniInnerversionAuditstatusModifyResponse.
    /// </summary>
    public class AlipayOpenMiniInnerversionAuditstatusModifyResponse : AopResponse
    {
    }
}
