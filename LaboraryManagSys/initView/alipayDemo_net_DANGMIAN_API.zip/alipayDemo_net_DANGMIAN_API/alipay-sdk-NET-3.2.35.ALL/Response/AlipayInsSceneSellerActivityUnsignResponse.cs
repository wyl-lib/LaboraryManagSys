using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayInsSceneSellerActivityUnsignResponse.
    /// </summary>
    public class AlipayInsSceneSellerActivityUnsignResponse : AopResponse
    {
    }
}
