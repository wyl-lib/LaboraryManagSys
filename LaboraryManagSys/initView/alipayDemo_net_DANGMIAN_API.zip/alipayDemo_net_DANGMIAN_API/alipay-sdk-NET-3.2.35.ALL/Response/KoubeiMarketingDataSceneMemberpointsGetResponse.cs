using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// KoubeiMarketingDataSceneMemberpointsGetResponse.
    /// </summary>
    public class KoubeiMarketingDataSceneMemberpointsGetResponse : AopResponse
    {
    }
}
