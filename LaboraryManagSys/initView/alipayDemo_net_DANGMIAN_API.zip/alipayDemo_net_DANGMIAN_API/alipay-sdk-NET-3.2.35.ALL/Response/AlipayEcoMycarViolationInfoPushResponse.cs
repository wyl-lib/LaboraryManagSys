using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayEcoMycarViolationInfoPushResponse.
    /// </summary>
    public class AlipayEcoMycarViolationInfoPushResponse : AopResponse
    {
    }
}
