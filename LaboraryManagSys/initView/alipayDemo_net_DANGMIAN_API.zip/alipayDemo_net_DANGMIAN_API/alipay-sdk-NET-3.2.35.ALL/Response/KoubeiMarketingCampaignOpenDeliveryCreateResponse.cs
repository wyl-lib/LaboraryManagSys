using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// KoubeiMarketingCampaignOpenDeliveryCreateResponse.
    /// </summary>
    public class KoubeiMarketingCampaignOpenDeliveryCreateResponse : AopResponse
    {
    }
}
