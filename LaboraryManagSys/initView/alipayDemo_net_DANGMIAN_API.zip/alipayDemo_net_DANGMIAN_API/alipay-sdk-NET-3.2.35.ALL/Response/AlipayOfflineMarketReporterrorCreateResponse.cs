using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOfflineMarketReporterrorCreateResponse.
    /// </summary>
    public class AlipayOfflineMarketReporterrorCreateResponse : AopResponse
    {
    }
}
