using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayCommerceMedicalInstcardBindResponse.
    /// </summary>
    public class AlipayCommerceMedicalInstcardBindResponse : AopResponse
    {
    }
}
