using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayUserCertifyInfoApplyResponse.
    /// </summary>
    public class AlipayUserCertifyInfoApplyResponse : AopResponse
    {
    }
}
