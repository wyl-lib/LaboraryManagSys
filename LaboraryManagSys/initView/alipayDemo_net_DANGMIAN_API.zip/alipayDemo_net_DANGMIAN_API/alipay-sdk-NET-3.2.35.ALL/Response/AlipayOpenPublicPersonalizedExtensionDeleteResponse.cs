using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenPublicPersonalizedExtensionDeleteResponse.
    /// </summary>
    public class AlipayOpenPublicPersonalizedExtensionDeleteResponse : AopResponse
    {
    }
}
