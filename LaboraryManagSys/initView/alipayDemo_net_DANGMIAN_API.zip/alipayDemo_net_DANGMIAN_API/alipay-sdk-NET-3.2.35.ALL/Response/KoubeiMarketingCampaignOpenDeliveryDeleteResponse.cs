using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// KoubeiMarketingCampaignOpenDeliveryDeleteResponse.
    /// </summary>
    public class KoubeiMarketingCampaignOpenDeliveryDeleteResponse : AopResponse
    {
    }
}
