using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// KoubeiAdvertCommissionAdvchannelUnbindResponse.
    /// </summary>
    public class KoubeiAdvertCommissionAdvchannelUnbindResponse : AopResponse
    {
    }
}
