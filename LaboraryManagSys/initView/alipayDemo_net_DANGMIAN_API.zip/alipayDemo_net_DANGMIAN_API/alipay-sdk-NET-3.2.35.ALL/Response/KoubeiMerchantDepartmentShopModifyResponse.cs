using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// KoubeiMerchantDepartmentShopModifyResponse.
    /// </summary>
    public class KoubeiMerchantDepartmentShopModifyResponse : AopResponse
    {
    }
}
