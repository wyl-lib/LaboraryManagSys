using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayEcoMycarTradeRefundResponse.
    /// </summary>
    public class AlipayEcoMycarTradeRefundResponse : AopResponse
    {
    }
}
