using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenPublicLabelModifyResponse.
    /// </summary>
    public class AlipayOpenPublicLabelModifyResponse : AopResponse
    {
    }
}
