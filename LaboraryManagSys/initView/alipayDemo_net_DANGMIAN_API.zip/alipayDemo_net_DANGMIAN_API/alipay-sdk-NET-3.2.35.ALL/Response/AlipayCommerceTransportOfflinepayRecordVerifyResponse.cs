using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayCommerceTransportOfflinepayRecordVerifyResponse.
    /// </summary>
    public class AlipayCommerceTransportOfflinepayRecordVerifyResponse : AopResponse
    {
    }
}
