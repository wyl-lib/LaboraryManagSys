using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayAccountExrateSentimentDataSendResponse.
    /// </summary>
    public class AlipayAccountExrateSentimentDataSendResponse : AopResponse
    {
    }
}
