using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayEcoMycarMaintainBizorderstatusUpdateResponse.
    /// </summary>
    public class AlipayEcoMycarMaintainBizorderstatusUpdateResponse : AopResponse
    {
    }
}
