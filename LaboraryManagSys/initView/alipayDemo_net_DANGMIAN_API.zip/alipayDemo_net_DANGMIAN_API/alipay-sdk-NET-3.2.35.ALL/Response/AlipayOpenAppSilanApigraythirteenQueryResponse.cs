using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenAppSilanApigraythirteenQueryResponse.
    /// </summary>
    public class AlipayOpenAppSilanApigraythirteenQueryResponse : AopResponse
    {
    }
}
