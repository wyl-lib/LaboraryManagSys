using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayBossFncXwbtestRetModifyResponse.
    /// </summary>
    public class AlipayBossFncXwbtestRetModifyResponse : AopResponse
    {
    }
}
