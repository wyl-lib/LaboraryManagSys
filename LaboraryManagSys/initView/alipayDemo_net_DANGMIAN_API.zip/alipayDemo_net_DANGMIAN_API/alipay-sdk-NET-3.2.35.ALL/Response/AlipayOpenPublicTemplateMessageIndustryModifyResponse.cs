using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenPublicTemplateMessageIndustryModifyResponse.
    /// </summary>
    public class AlipayOpenPublicTemplateMessageIndustryModifyResponse : AopResponse
    {
    }
}
