using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// KoubeiMarketingCampaignIntelligentPromoDeleteResponse.
    /// </summary>
    public class KoubeiMarketingCampaignIntelligentPromoDeleteResponse : AopResponse
    {
    }
}
