using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenMiniVersionAuditApplyResponse.
    /// </summary>
    public class AlipayOpenMiniVersionAuditApplyResponse : AopResponse
    {
    }
}
