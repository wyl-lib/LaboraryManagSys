using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenAppSilanLuckyeightQueryResponse.
    /// </summary>
    public class AlipayOpenAppSilanLuckyeightQueryResponse : AopResponse
    {
    }
}
